# -*- coding: utf-8 -*-
"""
Created on Thu Oct  3 07:10:34 2019

@author: C57103
"""

#Need to install requests package for python
import requests
def createInc(caller,short_desc,desc,assig_group,assigned_to,urgency='3',impact='2'):
    
     
        # Set the request parameters
        url = "https://dev59359.service-now.com/api/now/table/incident";
        
        # Eg. User name="username", Password="password" for this code sample.
        user = "admin"
        pwd = 'Aamir123#'
        
        # Set proper headers
        headers = {"Content-Type":"application/xml","Accept":"application/json"}
        
        # Do the HTTP request
        response = requests.post(url, auth=(user, pwd), headers=headers, data="<request><entry><caller_id>"+caller+"</caller_id><short_description>"+short_desc+"</short_description><description>"+desc+"</description><assignment_group>"+assig_group+"</assignment_group><assigned_to>"+assigned_to+"</assigned_to><urgency>"+urgency+"</urgency><impact>"+impact+"</impact></entry></request>")
        
        # Check for HTTP codes other than 201
        if response.status_code != 201:
            return "CI_FAIL"
            #print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:', response.json())
            #exit()
        
        # Decode the JSON response into a dictionary and use the data
        data = response.json()
        #print(data)
        incident_no=data["result"]["number"]
        incident_sys_id=data["result"]["sys_id"]
        incident_opened=data["result"]["opened_at"]
        #incident_link=data["result"][0][]
        return incident_no,incident_sys_id,incident_opened;
    
        
def main():
    
         createInc("abel.tuter@example.com","KIB2 Werkinstructie-2nd","FE001:File D:\Data\TesDataFile.txt is empty","AMS_IT_MANAGEMENT","adam.linton@example.com");
     
main();
