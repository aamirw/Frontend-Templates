# -*- coding: utf-8 -*-
"""
Created on Thu Oct  3 12:53:52 2019

@author: C57099
"""
from flask_table import Table, Col

class ItemTable(Table):
    name = Col('Name')
    description = Col('Description')

# Get some objects
class Item(object):
    def __init__(self, name, description):
        self.name = name
        self.description = description


def display():
    items = [Item('Name1', 'Description1'),
         Item('Name2', 'Description2'),
         Item('Name3', 'Description3')]
    table = ItemTable(items)
    return (table.__html__());
    