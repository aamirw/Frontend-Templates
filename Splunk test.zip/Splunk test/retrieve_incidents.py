# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
 #Need to install requests package for python
import requests
#import json
def filter(desc_code,short_desc):
    # Set the request parameters
    
    
    query="sysparm_query="
    #print("1")
    #list_desc=desc_code.split(",")
    #print(len(list_desc))
    if len(desc_code)==0:
        query=query+"^short_descriptionLIKE"+short_desc+"^close_codeLIKESolved"
    elif (len(desc_code)==1):
        query=query+"descriptionLIKE"+desc_code[0]+"^short_descriptionLIKE"+short_desc+"^close_codeLIKESolved"
    else:
        code=""
        for i in range(0,len(desc_code)):
          code=code+"descriptionLIKE"+desc_code[i]+"^OR"  
        #print(code)
        query=query+code[0:len(code)-3]+"^short_descriptionLIKE"+short_desc+"^close_codeLIKESolved"
    
    #list_short_desc[]=short_dec.split(,)
    #robo_name=""
    #for j in range(len(list_short_desc[]-1)):
     #   robo_name=robo_name+list_short_desc[j]
    #query="sysparm_query=descriptionLIKE"+code[0:len(code)-3]+"^short_descriptionLIKE"+short_desc+"^close_codeLIKESolved"
    url = "https://dev59359.service-now.com/api/now/table/incident?"+query
    #print(url)
    # Eg. User name="username", Password="password" for this code sample.
    user = 'admin'
    pwd = 'Aamir123#'
    
    # Set proper headers
    headers = {"Accept":"application/json"}
    
    #params=[()]
    
    # Do the HTTP request
    response = requests.get(url, auth=(user, pwd), headers=headers)
    
    # Check for HTTP codes other than 200
    if response.status_code != 200: 
        return "RETRIEVE_FAIL"
        #print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:', response.content)
        #exit()
    
    # Decode the XML response into a dictionary and use the data
    #print(type(response.content))
    json_data=response.json()
    #print(json_data)
    closed_list=[]
    #print(len(json_data["result"]))
    for i in range(0,len(json_data["result"])):
        closed_list.append(json_data["result"][i]["close_notes"])
    return closed_list;
    #print(closed_list);
    #print(json_data["result"][0]["close_notes"])
    #print(response.content)
def main():
    filter(["LE001","CWE001","FE001"],"KIB2");
#main();
