# -*- coding: utf-8 -*-
"""
Created on Thu Oct  3 10:46:19 2019

@author: C45389
"""
import requests
def updateWorkNotes(sys_id,receiver):
    

# Set the request parameters
    url = 'https://dev59359.service-now.com/api/now/table/incident/'+sys_id

# Eg. User name="username", Password="password" for this code sample.
    user = 'admin'
    pwd = 'Aamir123#'

# Set proper headers
    headers = {"Content-Type":"application/xml","Accept":"application/xml"}

# Do the HTTP request
    response = requests.put(url, auth=(user, pwd), headers=headers, data="<request><entry><work_notes>Email Sent to the Assigned person: "+receiver+"</work_notes></entry></request>")

# Check for HTTP codes other than 200
    if response.status_code != 200: 
        print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:', response.content)
        exit()

# Decode the XML response into a dictionary and use the data
    #print(response.content)
def Email_send(receiver,sys_id):
    
    
    # Set the request parameters
    url = 'https://dev59359.service-now.com/api/now/v1/email'
    receiver_list=receiver.split(',')
    count=len(receiver_list)
    to=""
    # Eg. User name="admin", Password="admin" for this code sample.
    user = 'admin'
    pwd = 'Aamir123#'
    for i in range(0,count):
        to+="\"USER"+str(i)+" <"+receiver_list[i]+">\""
        if(i!=count-1):
            to+=","
    
    # Set proper headers
    headers = {"Content-Type":"application/json","Accept":"application/json"}
    
    # Do the HTTP request
    response = requests.post(url, auth=(user, pwd), headers=headers ,data="{\"to\":["+to+"],\"subject\":\"Hello There 11\",\"text\":\"Test Message\",\"html\":\"<b>Test Message</b>\",\"table_name\":\"incident\",\"table_record_id\":\"a9185d41071000105805f9fc7c1ed000\",\"headers\": { \"X-Custom\":\"header\"}}")
    # Check for HTTP codes other than 200
    if response.status_code != 200: 
        print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:',response.json())
        exit()
   
    json_data=response.json()
    if(len(json_data["result"]['id'])==0):
        
        return "EMAIL NOT SENT"
    else: 
        #print(json_data["result"]['id'])
        updateWorkNotes(sys_id,receiver)
        return "EMAIL SENT"
        


    # Decode the JSON response into a dictionary and use the data
    #data = response.json()
    #print(data)

#print(Email_send("test@test.com,test12@test.com","a9185d41071000105805f9fc7c1ed000"))