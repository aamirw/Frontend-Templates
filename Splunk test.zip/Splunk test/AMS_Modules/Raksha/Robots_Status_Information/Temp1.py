# -*- coding: utf-8 -*-
"""
Created on Thu Oct  3 14:58:46 2019

@author: C57099
"""
import AdvancedHTMLParser

#parser = AdvancedHTMLParser.AdvancedHTMLParser();
#parser.parseFile("Hackathon_Output.html");
dictList = [ 
{'SerialNo': '1', 'RobotName': 'Kirk', 'SuccessRun': '224567', 'Failurecount':'5','failurewithoutchange':'3','NeedAttention':'1'},
{'SerialNo': '2', 'RobotName': 'Kirk', 'SuccessRun': '224567', 'Failurecount':'5','failurewithoutchange':'3','NeedAttention':'1'},
{'SerialNo': '3', 'RobotName': 'Kirk', 'SuccessRun': '224567', 'Failurecount':'5','failurewithoutchange':'3','NeedAttention':'1'},
{'SerialNo': '4', 'RobotName': 'Kirk', 'SuccessRun': '224567', 'Failurecount':'5','failurewithoutchange':'3','NeedAttention':'1'},
{'SerialNo': '5', 'RobotName': 'Kirk', 'SuccessRun': '224567', 'Failurecount':'5','failurewithoutchange':'3','NeedAttention':'1'}]
print(dictList);