# -*- coding: utf-8 -*-
"""
Created on Thu Oct  3 14:22:57 2019

@author: C57103
"""
import requests
def allIncidents(robot_name):
    query="https://dev59359.service-now.com/api/now/table/incident?sysparm_query=short_descriptionLIKE"+robot_name+"^close_atISNOTEMPTY"
    #url = "https://dev59359.service-now.com/api/now/table/incident?"+query
    #print(url)
    # Eg. User name="username", Password="password" for this code sample.
    user = 'admin'
    pwd = 'Aamir123#'
    
    # Set proper headers
    headers = {"Accept":"application/json"}
    
    #params=[()]
    
    # Do the HTTP request
    response = requests.get(query, auth=(user, pwd), headers=headers)
    
    # Check for HTTP codes other than 200
    if response.status_code != 200: 
        return "RETRIEVE_ALL_INCIDENTS_FAIL"
    json_data=response.json()
    print(json_data)
    inc_dict={}
    for i in range(0,len(json_data["result"])):
        inc_dict.update({(json_data["result"][i]["number"]):[json_data["result"][i]["description"],json_data["result"][i]["opened_at"]]})
        
    print(inc_dict);
    
def main():
    allIncidents("KIB2");
    
main();