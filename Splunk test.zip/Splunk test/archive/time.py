from datetime import datetime
dateTimeObj = datetime.now()
 
timestampStr = dateTimeObj.strftime("%d-%m-%Y (%H:%M:%S.%f)")

timestampStr = dateTimeObj.strftime("%m/%d/%Y:%H:%M:%S") 
print('Current Timestamp : ', timestampStr)
