#!/usr/bin/env python
#
# Copyright 2011-2015 Splunk, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License"): you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

"""A command line utility for executing Splunk searches."""

from __future__ import absolute_import
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from time import sleep

from splunklib.binding import HTTPError
import splunklib.client as client
import json
from datetime import datetime
from create_incident import *
from retrieve_incidents import *
from emailsend import *

try:
    from utils import *
except ImportError:
    raise Exception("Add the SDK repository to your PYTHONPATH to run the examples "
                    "(e.g., export PYTHONPATH=~/splunk-sdk-python.")

FLAGS_TOOL = [ "verbose" ]

FLAGS_CREATE = [
    "earliest_time", "latest_time", "now", "time_format",
    "exec_mode", "search_mode", "rt_blocking", "rt_queue_size",
    "rt_maxblocksecs", "rt_indexfilter", "id", "status_buckets",
    "max_count", "max_time", "timeout", "auto_finalize_ec", "enable_lookups",
    "reload_macros", "reduce_freq", "spawn_process", "required_field_list",
    "rf", "auto_cancel", "auto_pause",
]

FLAGS_RESULTS = [
    "offset", "count", "search", "field_list", "f", "output_mode"
]

def cmdline(argv, flags, **kwargs):
    """A cmdopts wrapper that takes a list of flags and builds the
       corresponding cmdopts rules to match those flags."""
    rules = dict([(flag, {'flags': ["--%s" % flag]}) for flag in flags])
    return parse(argv, rules, ".splunkrc", **kwargs)

def execute_splunk_search_query(argv):
    usage = 'usage: %prog [options] "search"'

    flags = []
    flags.extend(FLAGS_TOOL)
    flags.extend(FLAGS_CREATE)
    flags.extend(FLAGS_RESULTS)
    opts = cmdline(argv, flags, usage=usage)

    if len(opts.args) != 1:
        error("Search expression required", 2)
    search = opts.args[0]

    verbose = opts.kwargs.get("verbose", 0)

    kwargs_splunk = dslice(opts.kwargs, FLAGS_SPLUNK)
    kwargs_create = dslice(opts.kwargs, FLAGS_CREATE)
    kwargs_results = dslice(opts.kwargs, FLAGS_RESULTS)
    service = client.connect(**kwargs_splunk)

    try:
        service.parse(search, parse_only=True)
    except HTTPError as e:
        cmdopts.error("query '%s' is invalid:\n\t%s" % (search, str(e)), 2)
        return

    job = service.jobs.create(search, **kwargs_create)
    while True:
        while not job.is_ready():
            pass
        stats = {'isDone': job['isDone'],
                 'doneProgress': job['doneProgress'],
                 'scanCount': job['scanCount'],
                 'eventCount': job['eventCount'],
                 'resultCount': job['resultCount']}
        progress = float(stats['doneProgress'])*100
        scanned = int(stats['scanCount'])
        matched = int(stats['eventCount'])
        results = int(stats['resultCount'])
        if verbose > 0:
            status = ("\r%03.1f%% | %d scanned | %d matched | %d results" % (
                progress, scanned, matched, results))
            sys.stdout.write(status)
            sys.stdout.flush()
        if stats['isDone'] == '1': 
            if verbose > 0: sys.stdout.write('\n')
            break
        sleep(2)

    if 'count' not in kwargs_results: kwargs_results['count'] = 0
    results = job.results(**kwargs_results)
    myResults=""
    while True:
        content = results.read(1024)
        if len(content) == 0: break
        myResults+=content.decode('utf-8')
    resultJson = json.loads(myResults)
    #print(resultJson["results"])
    #print(resultJson["results"][0]["_raw"])
    job.cancel()
    return resultJson["results"]

def monitor_robot_runs(query, robot_name, list_of_error_codes):
    global caller
    global receiver
    global assignment_group
    global assigned_to
    global list_of_error_code
    global list_of_robots
    global incident_nav_baselink
    global successful_run_count
    global failed_run_with_incident_count
    global failed_run_without_incident_count
    
    allResultsForRobot = execute_splunk_search_query(query)
    roboCounterList = []
    for result in allResultsForRobot:
        counterList=[0,0]
        resultDescription = result["_raw"]
        identified_error_codes = []
        incidentFlag = False
        incident_nav_link = None
        email_status_response = None
        suggested_solutions=None
        CI_response=None
        #print(resultDescription)
        for error_code in list_of_error_codes:
            if error_code in resultDescription:
                incidentFlag = True
                identified_error_codes.append(error_code)

        suggested_solutions = filter(identified_error_codes,robot_name)

        if suggested_solutions != "RETRIEVE_FAIL":
            print(suggested_solutions)
        if incidentFlag==True:
            CI_response = createInc(caller,robotName,resultDescription,assignment_group,assigned_to)
            if CI_response == "CI_FAIL":
                retrieved_data = retrieveFromCounterMemory();
                if retrieved_data!=None and retrieved_data!="":
                    failed_run_without_incident_count=int(retrieved_data.split(",")[1])
                failed_run_without_incident_count += 1
                counterList[1]=failed_run_without_incident_count
            else:
                if CI_response!=None:
                    incident_number, incident_sysid, incident_openedate = CI_response
                    if incident_number != "":
                        incident_nav_link = incident_nav_baselink+incident_number
                        print(incident_number+" created")
                        print(incident_nav_link)
                    if incident_sysid != "":
                        email_status_response = Email_send(receiver,incident_sysid)
        else:
            retrieved_data = retrieveFromCounterMemory();
            if retrieved_data!=None and retrieved_data!="":
                successful_run_count=int(retrieved_data.split(",")[0])
            successful_run_count+=1
            counterList[0]=successful_run_count
        roboCounterList.append(counterList)            
        storeToCounterMemory(roboCounterList)

def retrieveFromCounterMemory():
    path = 'counter_mem.dat'
    with open(path, 'r') as counter_mem:
        counter_mem.read()

def storeToCounterMemory(roboCounterList):
    path = 'counter_mem.dat'
    global successful_run_count
    global failed_run_with_incident_count
    global failed_run_without_incident_count
    with open(path, 'w') as counter_mem:
        counter_mem.write(str(roboCounterList))
    

firstRun_InitializeSystem = True                
caller = "abel.tuter@example.com"
receiver = "abel.tuter@example.com, adam.linton@example.com,bryant.bouliouris@example.com"
assignment_group = "AMS_IT_MANAGEMENT"
assigned_to = "bryant.bouliouris@example.com"
list_of_error_codes = ["LE001","FBE001","FBE002","LE002","DSE001","FE001","CWE001"]
list_of_robots = ["FBLoginBot.robot", "DataScrapingBot.robot", "ContentWritingBot.robot"]
incident_nav_baselink = "https://dev59359.service-now.com/incident.do?sysparm_query=number="
successful_run_count = 0
failed_run_with_incident_count = 0
failed_run_without_incident_count = 0

if __name__ == "__main__":
    baseQuery = 'search source="test.log" host="DEMOHOST" sourcetype="AMSSourceType"'
    query = ['']
    dateTimeObj = datetime.now()
    #timestampStr = dateTimeObj.strftime("%d-%m-%Y (%H:%M:%S.%f)")
    timestampStr = dateTimeObj.strftime("%m/%d/%Y:%H:%M:%S")
    
    #robotName='"ContentWritingBot.robot"'
    timestampStr="10/03/2019:3:00:0"
    for robotName in list_of_robots:
        query[0]=baseQuery+" "+robotName+" earliest="+timestampStr
        print("\n"+robotName+":")
        #print(query)
        monitor_robot_runs(query, robotName, list_of_error_codes)
