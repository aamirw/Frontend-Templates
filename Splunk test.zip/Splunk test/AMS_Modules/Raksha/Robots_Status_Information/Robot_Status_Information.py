# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

#!flask/bin/python
from flask import Flask, render_template
from Test1 import * ;

app = Flask(__name__)

@app.route("/")
def index():
    dictList = [ 
{'SerialNo': '1', 'RobotName': 'Kirk', 'SuccessRun': '224567', 'Failurecount':'5','failurewithoutchange':'3','NeedAttention':'1'},
{'SerialNo': '2', 'RobotName': 'Kirk', 'SuccessRun': '224567', 'Failurecount':'5','failurewithoutchange':'3','NeedAttention':'1'},
{'SerialNo': '3', 'RobotName': 'Kirk', 'SuccessRun': '224567', 'Failurecount':'5','failurewithoutchange':'3','NeedAttention':'1'},
{'SerialNo': '4', 'RobotName': 'Kirk', 'SuccessRun': '224567', 'Failurecount':'5','failurewithoutchange':'3','NeedAttention':'1'},
{'SerialNo': '5', 'RobotName': 'Kirk', 'SuccessRun': '224567', 'Failurecount':'5','failurewithoutchange':'3','NeedAttention':'1'}]
    print(dictList);
    return render_template("Hackathon_Output.html", my_list=dictList);
#\\\solon.prd\\files\\P\\Global\\Users\\C57099\\UserData\\Desktop\\Project hackathon\\Robots_Status_Information\\templates\\

if __name__ == '__main__':
    app.run(debug=True)
    
